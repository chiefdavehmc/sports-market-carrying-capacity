# Lane B — Memphis market carrying capacity

**Market:** Memphis only  
**Properties:** Grizzlies, Tigers men's basketball, Tigers football, Redbirds  
**Period:** 2000–2025  
**Unit:** property-season and annual market totals  
**Primary use:** reported visits, visits per resident, property decomposition, and Memphis-only diagnostics

**Permitted inference:** Strong descriptive evidence that Memphis's sustainable repeat-visit volume has changed and that losses are nonuniform across properties.

**Not permitted:** This lane does not estimate the household-pressure × opponent-pull interaction and does not establish affordability causality.
