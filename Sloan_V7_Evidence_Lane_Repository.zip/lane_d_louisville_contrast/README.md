# Lane D — Louisville structural/economic contrast

**Market:** Louisville  
**Role:** purposeful contrast, not direct Memphis ecosystem twin  
**Primary use:** test whether household economics alone is sufficient to explain recurring-attendance decline

**Permitted inference:** Louisville's sharp Triple-A decline despite stronger household economics is a guardrail against a one-variable affordability explanation.

**Not permitted:** Do not average Louisville into the direct ecosystem-matched peer set or imply identical sports competition.
