# Sloan V7 Evidence-Lane Repository

**Author / accountable researcher:** Charles David Haner  
**AI research-analysis partner:** Morgan (OpenAI ChatGPT)

This repository deliberately separates four complementary evidence lanes. The analyses may converge on a common sports-market carrying-capacity hypothesis, but no result should be interpreted as if it came from a market or sample that did not generate it.

## Lanes

- `lane_a_basketball/` — 241-game Memphis/Marquette/Creighton basketball selectivity analysis.
- `lane_b_memphis_longitudinal/` — Memphis-only long-run sports-market carrying-capacity reconstruction.
- `lane_c_okc_peer_check/` — preliminary ecosystem-matched Memphis–Oklahoma City cross-sport check.
- `lane_d_louisville_contrast/` — Louisville structural/economic contrast used as a guardrail, not a direct peer.
- `audit/` — claim-to-lane manifest and controlling evidence architecture.
- `docs/` — abstract and collaboration disclosure.

## Controlling inference rule

The analyses do **not** constitute one causal model. Each lane answers a different question and has a different unit of analysis and inferential boundary.
