# When Life Wins: Household Pressure, Repeat Visits, and Sports-Market Carrying Capacity

## Introduction

Sports attendance is usually analyzed property by property even though households allocate one constrained budget across teams, leagues, entertainment, and necessities. We treat annual sports visits—not simply fans or tickets—as a shared metropolitan resource and ask whether household pressure reduces repeat-visit capacity by raising the threshold ordinary events must clear to earn discretionary spending.

## Methods

We use three complementary analyses, each answering a different question. First, a 241-game men’s basketball panel covering Memphis, Marquette, and Creighton across five non-COVID seasons tests within-event selectivity using program-season fixed effects, common game controls, and an opponent-pull measure. Second, a Memphis longitudinal reconstruction tracks reported attendance for the Grizzlies, Tigers men’s basketball, Tigers football, and Redbirds from 2000 through 2025 to measure market-level visit capacity and population-normalized change. Third, a preliminary ecosystem-matched comparison contrasts Memphis with Oklahoma City across NBA, college basketball, football, and Triple-A baseball; Louisville is retained separately as a structural/economic contrast rather than a direct peer.

## Results

In the basketball panel, Memphis’s schedule-adjusted attendance index fell from 100 in 2019-20 to 70.3 in 2024-25, while Marquette and Creighton averaged about 104.1 relative to their own baselines. An exploratory household-pressure × opponent-pull interaction improves model fit from R-squared 0.8345 to 0.8405 and is positive with an HC3 t-statistic near 2.0, consistent with greater event selectivity under pressure. Separately, Memphis’s four core properties generated 1.974 million reported visits in 2001 versus 1.171 million in 2025. Metropolitan population increased about 10.3%, yet core sports visits per resident fell 46.2%, from 1.62 to 0.87; losses were concentrated in Redbirds and Tigers basketball rather than uniformly across properties. In the matched-market check, Memphis basketball and Triple-A baseball weakened more than Oklahoma City’s comparable properties, while NBA attendance remained resilient in both. Louisville’s sharp Triple-A decline despite stronger household economics shows that affordability alone is not sufficient.

## Conclusion

The three analyses do not constitute one causal model; they test different parts of a common mechanism. Together they support a sports-market carrying-capacity framework in which household pressure may raise the threshold for routine visits, while product appeal, performance, pricing, and market structure determine where the losses appear. The practical question becomes not only “How many fans exist?” but “How many visits can this market sustainably activate, and which events remain worth the household tradeoff?”