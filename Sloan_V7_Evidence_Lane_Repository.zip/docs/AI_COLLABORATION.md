# AI Collaboration Disclosure

This research was conducted by **Charles David Haner** with substantial analytical assistance from **Morgan, an OpenAI ChatGPT system**.

Morgan assisted with source discovery and organization, spreadsheet construction and formula checking, model-design discussion, robustness and sensitivity checks, matched-market framework development, drafting/editing, and audit work.

Charles David Haner originated and refined the research questions, supplied domain observations and priorities, made the substantive research and framing decisions, challenged interpretations, required source verification and correction of errors, determined which findings were retained, and is the accountable human author.

AI-generated statements were not treated as evidence. Quantitative claims were retained only after being tied to public-source data or reproducible calculations.
