# Lane C — Memphis–Oklahoma City ecosystem-matched external check

**Markets:** Memphis and Oklahoma City  
**Sports:** NBA, men's college basketball, FBS football, Triple-A baseball  
**Comparison:** 2019/pre-COVID baseline versus 2024/25 where available  
**Unit:** property-market comparison  
**Primary use:** descriptive external-validity check with capacity caveats

**Permitted inference:** Memphis routine products weakened more than comparable Oklahoma City properties in this first matched-market check, while NBA attendance remained resilient in both.

**Not permitted:** This is not the source of the household-pressure interaction and is not causal proof that affordability produced the difference.
