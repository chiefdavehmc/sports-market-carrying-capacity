# Lane A — Within-event basketball selectivity

**Markets/programs:** Memphis, Marquette/Milwaukee, Creighton/Omaha  
**Sample:** 241 regular-season home games across five non-COVID seasons  
**Unit:** game nested in program-season  
**Primary use:** schedule-adjusted attendance and exploratory household-pressure × opponent-pull selectivity test

**Permitted inference:** Within this basketball sample, higher household pressure is associated with greater concentration of attendance toward higher-pull games.

**Not permitted:** Do not attribute this interaction to Oklahoma City, Louisville, NBA, AAA, or the Memphis whole-market series.
