# AI Collaboration Disclosure

This research was conducted by **Charles David Haner** with substantial analytical assistance from **Morgan, an OpenAI ChatGPT system**.

## Roles

Morgan assisted with:
- research-source discovery and organization;
- spreadsheet construction and formula checking;
- statistical/model-design discussion;
- robustness and sensitivity checks;
- matched-market framework development;
- drafting, editing, and consistency review;
- identifying denominator and comparability problems during audit.

Charles David Haner:
- originated and refined the research questions;
- supplied domain observations and research priorities;
- made the substantive research and framing decisions;
- reviewed model outputs and challenged interpretations;
- required source verification and correction of errors;
- determined which findings were strong enough to retain;
- is the accountable human author of the submission.

AI-generated statements were **not treated as evidence**. Quantitative claims were retained only after being tied to source data or a reproducible workbook calculation. The project intentionally records corrections—for example, replacing scheduled-home-game denominators with actual Triple-A home openings when the audit showed the original denominator was inappropriate.

The collaboration is disclosed to demonstrate a human-led, auditable use of an AI research partner rather than to imply that the AI system independently assumes authorship, legal responsibility, or research accountability.
