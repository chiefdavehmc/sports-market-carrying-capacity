# When Life Wins: Household Pressure, Repeat Visits, and Sports-Market Carrying Capacity

**Author / accountable researcher:** Charles David Haner  
**AI research-analysis partner:** Morgan (OpenAI ChatGPT)

This repository package supports the MIT Sloan Sports Analytics Conference abstract submission. It contains the public-data analysis workbook, reproducibility extracts, a claim-by-claim audit, and documentation of the human-AI research workflow.

## Research question

Sports attendance is usually analyzed property by property. This project instead treats annual sports visits as a shared metropolitan resource and asks whether changing household economic headroom raises the threshold ordinary events must clear to earn discretionary spending.

## What is measured here

- 241-game men's college basketball panel across Memphis, Marquette, and Creighton over five non-COVID seasons.
- Schedule-adjusted attendance and opponent-pull models.
- Memphis long-run core sports visit reconstruction.
- Performance / expectation residual diagnostics.
- First matched-market checks using an ecosystem-matched Oklahoma City comparison and Louisville as an economic/structural contrast.
- Usable/configured venue-capacity checks where public evidence supports them.

## Important interpretation boundary

Reported attendance is an event-visit measure, not a unique-fan count, paid-ticket count, or scan count. The economic-pressure interaction is exploratory and should not be interpreted as causal elasticity.

## Package structure

- `docs/Haner_Sloan_Abstract_V6_Submission.docx` — current abstract submission candidate.
- `analysis/Memphis_Sloan_Household_Economics_v29_Submission_Audit.xlsx` — controlling workbook with submission audit.
- `data/basketball_5season_panel.csv` — underlying five-season basketball panel.
- `data/economic_selectivity_tests.csv` — economic-pressure interaction results and robustness checks.
- `data/final_oct1_tests.csv` — long-run Memphis per-capita and property-decomposition tests.
- `data/peer_sports_inventory.csv` — matched/contrast market sports inventory and corrected attendance denominators.
- `data/peer_headroom_bridge.csv` — first-pass household-headroom comparison.
- `data/v6_claim_audit.csv` — every quantitative V6 claim mapped to its controlling evidence.
- `AI_COLLABORATION.md` — disclosure of AI assistance and human responsibility.
- `REPRODUCE.md` — reproduction path.
- `DATA_DICTIONARY.md` — key definitions and exclusions.
- `SOURCES.md` — major source families.

## Reproducibility

The controlling workbook contains source URLs in source columns and notes. Public source data are included or linked where practical. Some figures originate from official team/venue pages, Census/FRED, Basketball-Reference, MiLB/Baseball America/Ballpark Digest, and other documented public sources.

## License / rights

This package is intended for research reproducibility. Source data remain subject to their original publishers' terms and rights. Users should follow linked source terms when redistributing third-party data.
