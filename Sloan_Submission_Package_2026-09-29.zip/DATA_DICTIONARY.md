# Data Dictionary

- **Reported attendance / visits:** Published attendance counts treated as event visits. Not assumed to equal unique fans, paid tickets, or scans.
- **Core Memphis properties:** Memphis Grizzlies, Memphis Tigers men's basketball, Memphis Tigers football, Memphis Redbirds.
- **Usable/configured capacity:** Seats realistically available for sale/attendance in the relevant period after renovations, tarping, curtaining, or restricted sections where documented.
- **Nominal capacity:** Published venue capacity without adjustment for temporary configuration.
- **Schedule-adjusted attendance index:** Model-derived attendance level normalized to the 2019-20 program baseline.
- **Opponent Pull:** Recurring-opponent attraction measure derived from attendance in other seasons; used as an event-demand control.
- **Stress A:** Broad household-pressure composite using renter burden and real household-income information.
- **Ecosystem-matched peer:** Market selected for similar sports inventory/competitive structure before examining attendance outcomes.
- **Economic / structural contrast:** Market intentionally retained despite different sports inventory in order to examine substitution and competition.
- **COVID exclusion:** 2020-21 basketball season excluded from the five-season core because attendance operated under abnormal capacity rules.
