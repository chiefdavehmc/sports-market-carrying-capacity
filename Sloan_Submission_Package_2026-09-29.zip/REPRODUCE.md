# Reproduction Guide

1. Open `analysis/Memphis_Sloan_Household_Economics_v29_Submission_Audit.xlsx`.
2. Review `Basketball 5-season panel` for the 241-game analysis dataset.
3. Review `Basketball model results` for the schedule-adjusted attendance model and robustness results.
4. Review `Economic selectivity tests` for the household-pressure × opponent-pull interaction.
5. Review `Expectation residual test` for win-only explanatory-power diagnostics.
6. Review `Market 2000-25` and `Final Oct1 tests` for the long-run Memphis market reconstruction, population normalization, and property decomposition.
7. Review `Peer sports inventory v1` for the first ecosystem-matched and structural-contrast comparisons.
8. Review `V6 submission audit` for a one-row-per-claim audit of the submitted abstract.

## Key checks

- Memphis adjusted basketball index: about 70.3 in 2024-25 relative to 2019-20 = 100.
- Peer adjusted index: about 104.1 for Marquette/Creighton relative to their own baselines.
- Sports-only R²: 0.8345.
- Pressure × opponent-pull model R²: 0.8405; HC3 t ≈ 2.0.
- Win-only R²: about 0.451 for Memphis men's basketball; 0.418 for football.
- Core Memphis visits: 1,974,063 in 2001 and 1,171,165 in 2025.
- Core visits per resident: 1.62 to 0.87, a decline of about 46.2%.
- First matched-market descriptive check:
  - Memphis MBB: -26.9% vs Oklahoma MBB: -13.0%.
  - Memphis AAA: -41.1% vs Oklahoma City AAA: -18.4% using actual home openings.
  - Memphis Grizzlies and Oklahoma City Thunder attendance remain resilient relative to their pre-COVID baselines.

## Boundaries

The matched-market check is descriptive and preliminary. The abstract does not claim that the matched-market differences establish causality. The pressure × opponent-pull test is exploratory because there are 15 market-seasons and opponent pull is derived from other-season attendance behavior.
