# Major Source Families

The workbook retains row-level URLs and source notes. Major source families include:

- University of Memphis athletics — basketball, football, venue and historical attendance.
- Marquette University athletics — men's basketball game/season information.
- Creighton University athletics — men's basketball game/season information.
- University of Oklahoma athletics — basketball and football attendance.
- University of Louisville athletics — basketball and football attendance.
- Basketball-Reference — NBA season attendance.
- Minor League Baseball / Baseball America / Ballpark Digest — Triple-A attendance and actual home openings.
- U.S. Census Bureau / American Community Survey — population, household income, renter burden, and related metro/county characteristics.
- FRED — Census-derived metropolitan population series and macroeconomic reference series.
- BLS — CPI reference series.
- Project source register sheets — additional ticket, promotion, venue, and economic references.

Where a source reports a total attendance figure but not actual home openings, the project does not infer an average from scheduled home dates if actual openings are available elsewhere.
